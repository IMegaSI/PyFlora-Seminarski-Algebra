from  utils.DBUtils import DBUtils



class PlantService:

    TABLE_NAME = "plants"

    def __init__(self, sqlconnection):
        self.connection = sqlconnection
        self.createTable()
        #self._insertPlants() # zavrtit jednom da se napravi baza biljki (odrađeno)
        self.plants = []





    def createTable(self):
        query = f"""
                CREATE TABLE IF NOT EXISTS {self.TABLE_NAME}(
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                name            VARCHAR(30) NOT NULL UNIQUE,
                foto            VARCHAR(30) NOT NULL,
                description     VARCHAR(30) NOT NULL,
                zalijevanje     VARCHAR(30) NOT NULL,
                osvjetljenje    VARCHAR(30) NOT NULL,
                toplina         VARCHAR(30) NOT NULL,
                dohrana         BOOLEAN NOT NULL);
                """
        DBUtils.izvrsiIZapisi(self.connection, query)

    def createPlant (self, name, foto, description, zalijevanje, osvjetljenje, toplina, dohrana):
        query = f"""
                INSERT INTO {self.TABLE_NAME} (name, foto, description, zalijevanje, osvjetljenje, toplina, dohrana)
                VALUES ('{name}', '{foto}', '{description}', '{zalijevanje}', '{osvjetljenje}', '{toplina}', '{dohrana}');
                """
        DBUtils.izvrsiIZapisi(self.connection, query)

    def _insertPlants(self):
        self.createPlant("Aloe vera", "plants/aloa.jpg", "plants/aloe_vera.txt", "Mjesecno", "Sjenovito", "Umjerena", False)
        self.createPlant("Bosiljak", "plants/basil.jpg", "plants/bosiljak.txt", "Tjedno", "Jarko", "Toplija", True)
        self.createPlant("Kadulja", "plants/sage.jpg", "plants/kadulja.txt", "Tjedno", "Jarko", "Toplija", True)
        self.createPlant("Kopar", "plants/dill.jpg", "plants/kopar.txt", "Dnevno", "Sjenovito", "Umjerena", True)
        self.createPlant("Limuska Trava", "plants/lemongrass.png", "plants/limunska_trava.txt", "Dnevno", "Jarko", "Toplija", False)
        self.createPlant("Mazuran", "plants/marjoram.jpg", "plants/mazuran.txt", "Tjedno", "Sjenovito", "Toplija", True)
        self.createPlant("Metvica", "plants/mint.jpg", "plants/metvica.txt", "Dnevno", "Jarko", "Toplija", False)
        self.createPlant("Origano", "plants/oregano.jpg", "plants/origano.txt", "Tjedno", "Sjenovito", "Toplija", False)
        self.createPlant("Persin", "plants/parsely.jpg", "plants/persin.txt", "Dnevno", "Sjenovito", "Umjerena", True)
        self.createPlant("Ruzmarin", "plants/rosemary.jpg", "plants/ruzmarin.txt", "Tjedno", "Jarko", "Toplija", False)
        self.createPlant("Sljez", "plants/mallow.jpg", "plants/sljez.txt", "Dnevno", "Sjenovito", "Umjerena", True)
        self.createPlant("Timijan", "plants/thyme.jpg", "plants/timijan.txt", "Mjesecno", "Jarko", "Toplija", False)

    def getAllPlants(self):
        query = f"SELECT * FROM {self.TABLE_NAME}"
        cursor = self.connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()

        plants = []
        for row in rows:
            plant = {
                "id": row[0],
                "name": row[1],
                "foto": row[2],
                "description": row[3],
                "zalijevanje": row[4],
                "osvjetljenje": row[5],
                "toplina": row[6],
                "dohrana": bool(row[7])
            }
            plants.append(plant)

        return plants

    def getPlantById(self, plant_id):
        for plant in self.plants:
            if plant['id'] == plant_id:
                # Read the plant description from the text file
                with open(plant['description'], 'r') as f:
                    description = f.read().strip()


                return {
                    'id': plant['id'],
                    'name': plant['name'],
                    'foto': plant['foto'],
                    'zalijevanje': plant['zalijevanje'],
                    'osvjetljenje': plant['osvjetljenje'],
                    'toplina': plant['toplina'],
                    'dohrana': plant['dohrana'],
                    'description': description
                }

        return None
